﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using MvcEmployee.Data;
using System;
using System.Linq;

namespace MvcEmployee.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new MvcEmployeeContext(
                serviceProvider.GetRequiredService<
                    DbContextOptions<MvcEmployeeContext>>()))
            {
                // Look for any employees.
                if (context.Employee.Any())
                {
                    return;   // DB has been seeded
                }

                context.Employee.AddRange(
                    new Employee
                    {
                        EmployeeId = 1,
                        Name = "ABC",
                        DateOfBirth = DateTime.Parse("1989-2-12"),
                        Designation = "Manager"
                    },

                     new Employee
                     {
                         EmployeeId = 2,
                         Name = "PQR",
                         DateOfBirth = DateTime.Parse("1998-01-07"),
                         Designation = "Accountant"
                     },

                     new Employee
                     {
                         EmployeeId = 3,
                         Name = "XYZ",
                         DateOfBirth = DateTime.Parse("1999-01-01"),
                         Designation = "Developer"
                     },

                     new Employee
                     {
                         EmployeeId = 4,
                         Name = "John",
                         DateOfBirth = DateTime.Parse("1996-11-05"),
                         Designation = "Engineer"
                     }
                );

                context.Database.OpenConnection();
                context.Database.ExecuteSqlRaw("SET IDENTITY_INSERT dbo.Employee ON");
                context.SaveChanges();
            }
        }

    }
}
